temp_c = 30
temp_f = temp_c * 9 / 5 + 32
print("{}C => {}F".format(temp_f, temp_c))
print(temp_f)

temp_c = 0
temp_f = temp_c * 9 / 5 + 32
print("{}C => {}F".format(temp_f, temp_c))
print(temp_f)

height = 1.58
weight = 47
bmi = weight / height ** 2
print(bmi)

radius = 4
area = radius ** 2
print(area)

lower = 5
upper = 3
height = 4
trapezoid = (lower + upper) * height / 2.0
print(trapezoid)

